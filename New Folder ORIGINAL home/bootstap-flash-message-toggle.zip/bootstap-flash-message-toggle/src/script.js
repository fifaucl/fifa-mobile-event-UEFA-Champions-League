// Button click toggle the flash message
// replace it by a callback or what you want
$('.btn').click(function() {
  // Put it in a callback or what you want
  $('.flash-message').fadeIn(500).delay(1500 ).fadeOut(500);
});