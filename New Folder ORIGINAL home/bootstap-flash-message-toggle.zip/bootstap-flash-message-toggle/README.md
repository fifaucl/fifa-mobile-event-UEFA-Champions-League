# Bootstap flash message toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/manuelLandreau/pen/zEvVoW](https://codepen.io/manuelLandreau/pen/zEvVoW).

Simple Bootstap jquery flash message alert toggle