# Placeholders JQuery validation

A Pen created on CodePen.io. Original URL: [https://codepen.io/ogilvyDev/pen/DqrrvW](https://codepen.io/ogilvyDev/pen/DqrrvW).

This code snippet shows you how to use placeholders in form inputs for older browsers. There is also a custom jquery validation rule to handle these placeholders.